SELECT * FROM mintclassics.customers;

ALTER TABLE customers
CHANGE COLUMN customer_number customerNumber INT,
CHANGE COLUMN customer_name customerName VARCHAR(255),
CHANGE COLUMN contact_last_name contactLastName VARCHAR(255),
CHANGE COLUMN contact_first_name contactFirstName VARCHAR(255),
CHANGE COLUMN phone phone VARCHAR(50),
CHANGE COLUMN address_line_1 addressLine1 VARCHAR(255),
CHANGE COLUMN address_line_2 addressLine2 VARCHAR(255),
CHANGE COLUMN city city VARCHAR(100),
CHANGE COLUMN state state VARCHAR(100),
CHANGE COLUMN postal_code postalCode VARCHAR(20),
CHANGE COLUMN country country VARCHAR(100),
CHANGE COLUMN sales_rep_employee_number salesRepEmployeeNumber INT,
CHANGE COLUMN credit_limit CREDITLIMIT DECIMAL(10,2);

-- CHECK FOR DUPLICATE
SELECT *, row_number() OVER(partition by customer_number,
customer_name,
contact_last_name,
contact_first_name,
phone,
city,
state,
postal_code,
country,
sales_rep_employee_number,
credit_limit) AS ROW_NUM FROM customers;

WITH CTE AS (
SELECT *, row_number() OVER(partition by customer_number,
customer_name,
contact_last_name,
contact_first_name,
phone,
city,
state,
postal_code,
country,
sales_rep_employee_number,
credit_limit) AS ROW_NUM FROM customers)
select * FROM CTE WHERE ROW_NUM>1;
-- NO DUPLICATES FOUND--

with cte as (
select *, row_number() over(partition by customerNumber, customerName,salesRepEmployeeNumber order by customerNumber) as row_num from customers)
select * from cte where row_num >1;
-- No Duplicates found

-- trimming columns
UPDATE customers
SET
    customerName = TRIM(customerName),
    contactLastName = TRIM(contactLastName),
    contactFirstName = TRIM(contactFirstName),
    phone = TRIM(phone),
    addressLine1 = TRIM(addressLine1),
    addressLine2 = TRIM(addressLine2),
    city = TRIM(city),
    state = TRIM(state),
    postalCode = TRIM(postalCode),
    country = TRIM(country);
    
-- dropping uneffected columns
ALTER TABLE customers
DROP COLUMN contactLastName,
DROP COLUMN contactFirstName,
DROP COLUMN phone,
DROP COLUMN addressLine1,
DROP COLUMN addressLine2,
DROP COLUMN postalCode;

-- credit limit column standerdisation

 ALTER TABLE customers
 CHANGE column CREDITLIMIT creditLimit decimal(10,2);
 
 -- check customer name null  ==> NO NULL
	select * from customers where customerName is null;
	select * from customers where  city is null;
	select * from customers where creditLimit is null;
	select * from customers where  state is null; -- 73 null found -- imputing with NA
    Update customers
    set state='NA'
    where state is null;

select * from customers where country is null; -- no null

select * from customers where salesRepEmployeeNumber is null ; -- 22 nulls -- imputing with 0 -- not done
Update customers
    set salesRepEmployeeNumber= 0
    where salesRepEmployeeNumber is null;


 
 -- Analysis Customers -- 
 
 -- total customers ==> 122
 SELECT COUNT(*) AS total_customers FROM customers;

-- Customers by country and State
 select country, count(*) as customer_count from customers group by country order by country ;
 select state, count(*) as customer_count  from customers group by state order by state ;
 
 -- By City
SELECT 
    country,
    city,
    COUNT(*) AS customer_count
FROM customers
GROUP BY country, city
ORDER BY customer_count DESC;
 
 -- average customer purchasing power and risk exposure
 SELECT 
    ROUND(AVG(creditLimit), 2) AS avg_credit_limit
FROM customers; -- Avg credit limit is 67659.02 

-- Credit limit by region 
SELECT 
    country,
    ROUND(AVG(creditLimit), 2) AS avg_credit_limit
FROM customers
GROUP BY country
ORDER BY avg_credit_limit DESC;


 -- Top revenue generated customer ==> 98 ROWS RETURNED
 
 SELECT 
    c.customerNumber,
    c.customerName,
    c.country,
    c.city,
    ROUND(SUM(od.quantityOrdered * od.priceEach), 2) AS total_revenue
FROM customers c
JOIN orders o 
    ON c.customerNumber = o.customerNumber
JOIN orderdetails od 
    ON o.orderNumber = od.orderNumber
GROUP BY 
    c.customerNumber,
    c.customerName,
    c.country,
    c.city
ORDER BY total_revenue DESC;


