SELECT * FROM mintclassics.orderdetails;
SELECT * FROM mintclassics.orders;
-- ensure primary key is uneque == > zero rows returned
SELECT orderNumber, productCode, COUNT(*) AS cnt
FROM orderdetails
GROUP BY orderNumber, productCode
HAVING COUNT(*) > 1;

SELECT orderNumber, COUNT(*) AS cnt
FROM orders
GROUP BY orderNumber
HAVING COUNT(*) > 1;


-- NO DUPLICATES FOUND
WITH CTE AS (
SELECT orderNumber, productCode, row_number() OVER(partition by orderNumber, productCode ) AS ROW_NUM FROM orderdetails )
SELECT * FROM CTE WHERE ROW_NUM>1;

-- NO DUPLICATES FOUND
WITH CTE AS (
SELECT orderNumber, customerNumber, row_number() OVER(partition by orderNumber, customerNumber ) AS ROW_NUM FROM orders )
SELECT * FROM CTE WHERE ROW_NUM>1;

-- null check 
SELECT *
FROM orders
WHERE orderNumber IS NULL
   OR orderDate IS NULL
   OR requiredDate IS NULL
   OR status IS NULL
   OR customerNumber IS NULL;
   
SELECT *
FROM orderdetails
WHERE orderNumber IS NULL
   OR productCode IS NULL
   OR quantityOrdered IS NULL
   OR priceEach IS NULL
   OR orderLineNumber IS NULL;

SELECT *
FROM orders
WHERE shippedDate IS NULL; -- 14 rows returned

-- SHIPPED DATE NULL IS FLAGGED
ALTER TABLE orders
add column shippiedDateFalg int default 0;

UPDATE orders
SET shippiedDateFalg =1
WHERE shippedDate IS NULL;

-- Remove Logically Invalid Records ==> NO ROWS RETUNED
DELETE FROM orderdetails
WHERE quantityOrdered <= 0
   OR priceEach <= 0;

-- INVALID ORDER DATES ==> NO ROWS RETUNED
DELETE FROM orders
WHERE requiredDate < orderDate;

-- Invalid shipment dates
DELETE FROM orders
WHERE shippedDate IS NOT NULL
  AND shippedDate < orderDate;

-- STANDERDISE ORDER STATUS
UPDATE orders
SET STATUS = LOWER(TRIM(STATUS));

SELECT distinct STATUS
FROM orders;  -- > 6 STATUS VALUES - SHIPPED, REOLVED, CACELLED, ON HOLD, DISPUTED, IN PROCESS

SELECT *
FROM orders
WHERE orderDate IS NULL
   OR requiredDate IS NULL; -- >CHECK FOR IVALID DATES ==> NO DATES WITH NULLS.

-- CHECK FOR ABMORMAL PRICING
SELECT *
FROM orderdetails
WHERE priceEach > 100000;

SELECT COUNT(*) FROM orders; -- 326 ROWS
SELECT COUNT(*) FROM orderdetails;  -- 2996 ROWS

-- WHILE JOINING ORDERS AND ORDER DETAILS , CHECK THE ROW COUNTS
SELECT COUNT(*)
FROM orders o
JOIN orderdetails od
ON o.orderNumber = od.orderNumber; -- 2996 ROWS

-- CREATING A CLEAN JOINED RECORDS OF ORDERS AND ORDER DETAILS
-- JOINING ORDERS AND ORDER DETAILS FOR BETTER PERFORMANCE
CREATE VIEW vw_clean_orders AS
SELECT
    o.orderNumber,
    o.orderDate,
    o.requiredDate,
    o.shippedDate,
    o.status,
    o.customerNumber,
    od.productCode,
    od.quantityOrdered,
    od.priceEach,
    (od.quantityOrdered * od.priceEach) AS line_revenue
FROM orders o
JOIN orderdetails od
ON o.orderNumber = od.orderNumber;



-- ANALYSIS

-- KEY METRICS FOR INVENTORY & FACILITY CLOSURE DECISION

-- 1. Which products drive most of the demand?
SELECT
    productCode,
    SUM(quantityOrdered) AS total_units_sold,
    SUM(line_revenue) AS total_revenue,
    COUNT(DISTINCT orderNumber) AS order_count
FROM vw_clean_orders
GROUP BY productCode
ORDER BY total_units_sold DESC;

-- Business Insight
-- Top products must remain closest to shipping points.
-- These products cannot be disrupted during facility closure.

-- 2. Which inventory can be reduced safely? ==> METRIC : Average units sold per order

SELECT
    productCode,
    SUM(quantityOrdered) AS total_units_sold,
    COUNT(DISTINCT orderNumber) AS total_orders,
    ROUND(SUM(quantityOrdered) / COUNT(DISTINCT orderNumber), 2) AS avg_units_per_order
FROM vw_clean_orders
GROUP BY productCode
ORDER BY avg_units_per_order ASC;

-- Business Insight
-- Low avg_units_per_order + low order count = slow movers
-- Best candidates for inventory reduction or relocation

-- 3. Can we still ship within 24 hours? -- > METRIC : Time from order to shipment (in hours)
SELECT
    orderNumber,
    productCode,
    TIMESTAMPDIFF(HOUR, orderDate, shippedDate) AS fulfillment_hours
FROM vw_clean_orders
WHERE shippedDate IS NOT NULL; 

-- RETURNS 96, 48, 120, 24 ETC - MEANING MOST OF THE PRODUCTS NEED DELIVERY TIME MORE THAN 24 HOOURS BEFORE CLOSING THE SHOP. 
-- Every product in the same order has the same fulfillment time
-- SLA (SERVICE LEVEL AGREEMENT) = 24 hours
-- Fulfillment Time	SLA Status
-- ≤ 24 hours	SLA met
-- > 24 hours	SLA breached
-- Mint Classics is already failing its 24-hour promise — even before closing a facility.

-- CATEGORISATION OF HOWMANY PRODUCTS MET SLA AND NOT? ==> 2855 TOTAL ORDERS, 468 SLA MET,  ONLY 16.39 % FULL FILL THE REQUIRMENT.
SELECT
    COUNT(*) AS total_order_lines,
    SUM(CASE WHEN fulfillment_hours <= 24 THEN 1 ELSE 0 END) AS sla_met,
    ROUND(
        100.0 * SUM(CASE WHEN fulfillment_hours <= 24 THEN 1 ELSE 0 END)
        / COUNT(*), 2
    ) AS sla_compliance_pct
FROM (
    SELECT
        orderNumber,
        productCode,
        TIMESTAMPDIFF(HOUR, orderDate, shippedDate) AS fulfillment_hours
    FROM vw_clean_orders
    WHERE shippedDate IS NOT NULL
) t;

-- EXTREAM DELAYED ORDERS ==> 312 ROWS RETUNED 
SELECT
    orderNumber,
    MAX(TIMESTAMPDIFF(HOUR, orderDate, shippedDate)) AS max_fulfillment_hours
FROM vw_clean_orders
WHERE shippedDate IS NOT NULL
GROUP BY orderNumber
ORDER BY max_fulfillment_hours DESC;

-- FINDING THE DELAYED PRODUCTS
SELECT
    productCode,
    COUNT(*) AS late_order_lines
FROM vw_clean_orders
WHERE shippedDate IS NOT NULL
  AND TIMESTAMPDIFF(HOUR, orderDate, shippedDate) > 24
GROUP BY productCode
ORDER BY late_order_lines DESC;

-- Should not be moved farther away
-- May need higher safety stock

-- FINAL BUSINESS INSIGHTS --
 -- FROM values like 48, 96, 120 hours, you can confidently say: The 24-hour SLA is not consistently met
-- Current operations already show fulfillment delays
-- Closing a storage facility without inventory reallocation will worsen customer service
-- High-demand products involved in late shipments must remain closest to dispatch points

