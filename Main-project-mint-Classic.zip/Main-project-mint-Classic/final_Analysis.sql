-- FINAL ANALYSIS & SUGGESTINS TO MINT CLASSIC

-- 1. least demanded product ==>Candidates to STOP further stocking
SELECT
    productCode,
    SUM(quantityOrdered) AS total_units_sold
FROM vw_clean_orders
GROUP BY productCode
ORDER BY total_units_sold ASC
LIMIT 10;

-- “Do we currently hold significant inventory for products that customers barely buy?”
SELECT
    p.productCode,
    p.productName,
    p.quantityInStock
FROM products p
JOIN (
    SELECT productCode
    FROM vw_clean_orders
    GROUP BY productCode
    ORDER BY SUM(quantityOrdered) ASC
    LIMIT 10
) low_demand
ON p.productCode = low_demand.productCode;

-- Warehouse space is limited
-- Storing slow-moving products blocks capacity
-- Removing these products:
-- Reduces space needs
-- Enables closing a storage facility
-- Does not affect service levels

-- We cross-validated demand with current inventory and found products with very low sales velocity but non-trivial stock levels. These products are strong candidates for discontinuation, enabling inventory reduction without impacting customer service.

-- IS IT OKAY TO STOP STOCKING THEM?

-- YES — if ALL conditions are met:
-- Low demand
-- Low revenue contribution
-- Not critical for product line completeness

-- Revenue validation
SELECT
    od.productCode,
    SUM(od.quantityOrdered * od.priceEach) AS revenue
FROM orderdetails od
GROUP BY od.productCode
ORDER BY revenue ASC
LIMIT 10;

 -- =========================================================================
 
 
-- 2. WHICH WAREHOUSE CAN BE CLOSED WITH MINIMAL RISK?

-- Inventory load per warehouse ==> warehouse d is the least load
SELECT
    warehouseCode,
    SUM(quantityInStock) AS total_inventory
FROM products
GROUP BY warehouseCode
ORDER BY total_inventory ASC;

-- Demand linked to warehouse ==> Warehouse d is the least demand
SELECT
    p.warehouseCode,
    SUM(od.quantityOrdered) AS total_demand
FROM orderdetails od
JOIN products p
    ON od.productCode = p.productCode
GROUP BY p.warehouseCode
ORDER BY total_demand ASC;

-- from both we can decide that warehouse d is the potential candidate for closure.

 -- ============================================================================
 
 
-- 3. CAN WE MAINTAIN SLA (24-HOUR DELIVERY)?
-- MINT CLASSIC SLA --> Order shipped within 24 hours of order date

SELECT
    COUNT(*) AS total_orders,
    SUM(
        CASE
            WHEN TIMESTAMPDIFF(HOUR, o.orderDate, o.shippedDate) <= 24
            THEN 1 ELSE 0
        END
    ) AS sla_met_orders,
    SUM(
        CASE
            WHEN TIMESTAMPDIFF(HOUR, o.orderDate, o.shippedDate) > 24
            THEN 1 ELSE 0
        END
    ) AS sla_not_met_orders
FROM orders o
WHERE o.shippedDate IS NOT NULL;

-- > shows that total of 312 orders, only 50 orders met SLA. 
-- Current operations already show fulfillment delays
-- Closing a storage facility without inventory reallocation will worsen customer service
-- High-demand products involved in late shipments must remain closest to dispatch points

-- SLA met percentage
SELECT
    ROUND(
        SUM(
            CASE
                WHEN TIMESTAMPDIFF(HOUR, o.orderDate, o.shippedDate) <= 24
                THEN 1 ELSE 0
            END
        ) * 100.0 / COUNT(*),
        2
    ) AS sla_met_percentage
FROM orders o
WHERE o.shippedDate IS NOT NULL;

-- Our analysis shows that 16.03% of orders currently meet the 24-hour SLA, remaining violate it. This establishes a clear baseline before making any facility-closure decisions.”

-- ==================================================================================