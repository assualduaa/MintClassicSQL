SELECT * FROM mintclassics.employees;

-- checking for primary key uniqueness -- no rows returned
SELECT employeeNumber, COUNT(*)
FROM employees
GROUP BY employeeNumber
HAVING COUNT(*) > 1;

-- check for duplicates -- no duplicates
with cte as (
select *, row_number() over(partition by employeeNumber, email order by employeeNumber) as row_num from employees)
select * from cte where row_num >1; -- no duplicates found

-- removing uneffected column extension
ALTER TABLE employees
DROP COLUMN extension;

-- column wise null check 
SELECT
    SUM(employeeNumber IS NULL) AS employeeNumber_nulls,
    SUM(firstName IS NULL) AS firstName_nulls,
    SUM(lastName IS NULL) AS lastName_nulls,
    SUM(email IS NULL) AS email_nulls,
    SUM(officeCode IS NULL) AS officeCode_nulls,
    SUM(reportsTo IS NULL) AS reportsTo_nulls,
    SUM(jobTitle IS NULL) AS jobTitle_nulls
FROM employees;

-- reports to conteain 1 null - imputing with mode
UPDATE employees
SET reportsTo = (
    SELECT reportsTo
    FROM (
        SELECT reportsTo
        FROM employees
        WHERE reportsTo IS NOT NULL
        GROUP BY reportsTo
        ORDER BY COUNT(*) DESC
        LIMIT 1
    ) AS mode_manager
)
WHERE reportsTo IS NULL;

-- trim all columns
UPDATE employees
SET
    firstName = TRIM(firstName),
    lastName = TRIM(lastName),
    email = TRIM(email),
    jobTitle = TRIM(jobTitle);

-- Normalize Email Case
UPDATE employees
SET email = LOWER(email);

-- Data Type Validation
-- Validate Column Lengths
-- officeCode → varchar(10) is acceptable
-- email → varchar(100) sufficient
-- reportsTo → int (FK to employeeNumber)
-- No changes required unless inconsistent data exists.

-- check for invalid reports to == > No rows retuned
SELECT *
FROM employees e
WHERE reportsTo IS NOT NULL
  AND reportsTo NOT IN (
      SELECT employeeNumber FROM employees
  );

-- office code integrity check ==> no rows returned
SELECT *
FROM employees e
LEFT JOIN offices o
    ON e.officeCode = o.officeCode
WHERE o.officeCode IS NULL;

--  == Main KPI == 

-- Total Employees --> 23
SELECT COUNT(*) AS total_employees FROM employees;

-- employees by office 
SELECT officeCode, COUNT(*) AS employee_count
FROM employees
GROUP BY officeCode
ORDER BY employee_count DESC;

-- employees by Job title 
SELECT jobTitle, COUNT(*) AS role_count
FROM employees
GROUP BY jobTitle
ORDER BY role_count DESC;


-- Manager vs Individual Contributors
SELECT
    CASE
        WHEN employeeNumber IN (SELECT DISTINCT reportsTo FROM employees WHERE reportsTo IS NOT NULL)
        THEN 'Manager'
        ELSE 'Individual Contributor'
    END AS employee_type,
    COUNT(*) AS count
FROM employees
GROUP BY employee_type;

-- avg Team size per manager
SELECT reportsTo AS manager_id, COUNT(*) AS team_size
FROM employees
WHERE reportsTo IS NOT NULL
GROUP BY reportsTo;



