SELECT * FROM mintclassics.customers;

ALTER TABLE customers
CHANGE COLUMN customer_number customerNumber INT,
CHANGE COLUMN customer_name customerName VARCHAR(255),
CHANGE COLUMN contact_last_name contactLastName VARCHAR(255),
CHANGE COLUMN contact_first_name contactFirstName VARCHAR(255),
CHANGE COLUMN phone phone VARCHAR(50),
CHANGE COLUMN address_line_1 addressLine1 VARCHAR(255),
CHANGE COLUMN address_line_2 addressLine2 VARCHAR(255),
CHANGE COLUMN city city VARCHAR(100),
CHANGE COLUMN state state VARCHAR(100),
CHANGE COLUMN postal_code postalCode VARCHAR(20),
CHANGE COLUMN country country VARCHAR(100),
CHANGE COLUMN sales_rep_employee_number salesRepEmployeeNumber INT,
CHANGE COLUMN credit_limit CREDITLIMIT DECIMAL(10,2);

-- CHECK FOR DUPLICATE
SELECT *, row_number() OVER(partition by customer_number,
customer_name,
contact_last_name,
contact_first_name,
phone,
city,
state,
postal_code,
country,
sales_rep_employee_number,
credit_limit) AS ROW_NUM FROM customers;

WITH CTE AS (
SELECT *, row_number() OVER(partition by customer_number,
customer_name,
contact_last_name,
contact_first_name,
phone,
city,
state,
postal_code,
country,
sales_rep_employee_number,
credit_limit) AS ROW_NUM FROM customers)
select * FROM CTE WHERE ROW_NUM>1;
-- NO DUPLICATES FOUND--

with cte as (
select *, row_number() over(partition by customerNumber order by customerNumber) as row_num from customers)
select * from cte where row_num >1;
-- No Duplicates found

