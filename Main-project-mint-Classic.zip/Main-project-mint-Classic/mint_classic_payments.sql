SELECT * FROM mintclassics.payments;

-- CHECK FOR DUPLICATE PK ==> NO ROWS RETUNRED
SELECT
    customerNumber,
    checkNumber,
    COUNT(*) AS cnt
FROM payments
GROUP BY customerNumber, checkNumber
HAVING COUNT(*) > 1;

-- NULL check ==> NO NULL
SELECT *
FROM payments
WHERE customerNumber IS NULL
   OR checkNumber IS NULL
   OR paymentDate IS NULL
   OR amount IS NULL;

-- Logical Data Validation
-- Invalid payment amounts ==> NO ROWS EFFECTED
DELETE FROM payments
WHERE amount <= 0;

-- Invalid payment dates (future dates) ==> ZERO ROWS EFFECTED
DELETE FROM payments
WHERE paymentDate > CURRENT_DATE;

-- CLEAN CHECK NUMBER ==> 273 ROWS CHANGED
UPDATE payments
SET checkNumber = TRIM(UPPER(checkNumber)); 

-- OUTLIER DETECTION
SELECT *
FROM payments
WHERE amount > 100000;

-- Referential Integrity Check
-- Ensure every payment belongs to a valid customer. ==> No invalids
SELECT p.*
FROM payments p
LEFT JOIN customers c
ON p.customerNumber = c.customerNumber
WHERE c.customerNumber IS NULL;

-- REMOVE ORPHANS ==> NO ORPHANS FOUND
DELETE FROM payments
WHERE customerNumber NOT IN (
    SELECT customerNumber FROM customers
);

-- DUPLICAT EPAYMENT DETECTION == > NO DUPLICATES
SELECT
    customerNumber,
    paymentDate,
    amount,
    COUNT(*) AS cnt
FROM payments
GROUP BY customerNumber, paymentDate, amount
HAVING COUNT(*) > 1;

-- Pre-Aggregation Readiness Check  ==> METRIC : TOTAL PAYMENT = 273
SELECT COUNT(*) AS total_payments
FROM payments;

-- creating a clean view

CREATE VIEW vw_clean_payments AS
SELECT
    customerNumber,
    checkNumber,
    paymentDate,
    amount
FROM payments;

