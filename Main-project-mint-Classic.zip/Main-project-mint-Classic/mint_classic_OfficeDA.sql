SELECT * FROM mintclassics.offices;

-- primaryKey Uniqueness -- no row retunrned, hence unique
SELECT officeCode, COUNT(*)
FROM offices
GROUP BY officeCode
HAVING COUNT(*) > 1;

-- drop uneffected columns
ALTER TABLE offices DROP COLUMN phone;
ALTER TABLE offices DROP COLUMN addressLine1;
ALTER TABLE offices DROP COLUMN addressLine2;
ALTER TABLE offices DROP COLUMN postalCode;


-- duplicates ==> no duplicates
with cte as (
select territory, row_number() over(partition by officeCode, city order by territory) as row_num from offices)
select *, row_num from cte where row_num > 1 ;

-- column wise null check
SELECT
    SUM(officeCode IS NULL) AS officeCode_nulls,
    SUM(city IS NULL) AS city_nulls,
    SUM(state IS NULL) AS state_nulls,
    SUM(country IS NULL) AS country_nulls,
    SUM(territory IS NULL) AS territory_nulls
FROM offices;
 -- ==> state has nulls ==> replaced nulls
 
 UPDATE offices
SET state = 'Unknown'
WHERE state IS NULL;

UPDATE offices
SET territory = 'NA'
WHERE territory ='UNASSIGNED';

-- Trim Text Fields
UPDATE offices
SET
    city = TRIM(city),
    state = TRIM(state),
    country = TRIM(country),
    territory = TRIM(territory);

-- Normalize Case
UPDATE offices
SET
    city = UPPER(city),
    state = UPPER(state),
    country = UPPER(country),
    territory = UPPER(territory);


-- Offices Used by Employees
SELECT o.officeCode
FROM offices o
LEFT JOIN employees e
    ON o.officeCode = e.officeCode
WHERE e.officeCode IS NULL;

-- Flag Unused Offices
SELECT officeCode
FROM offices
WHERE officeCode NOT IN (
    SELECT DISTINCT officeCode FROM employees
);


-- ==== main KPI ====

-- Total Offices ==> 7 offices
SELECT COUNT(*) AS total_offices FROM offices;

-- Offices by Country
SELECT country, COUNT(*) AS office_count
FROM offices
GROUP BY country
ORDER BY office_count DESC;

-- Offices by Territory
SELECT territory, COUNT(*) AS office_count
FROM offices
GROUP BY territory
ORDER BY office_count DESC;

-- Employees per office
SELECT 
    o.officeCode,
    o.city,
    COUNT(e.employeeNumber) AS employee_count
FROM offices o
LEFT JOIN employees e ON o.officeCode = e.officeCode
GROUP BY o.officeCode, o.city
ORDER BY employee_count DESC;

-- Office with low Staffing
SELECT 
    o.officeCode,
    o.city,
    COUNT(e.employeeNumber) AS employee_count
FROM offices o
LEFT JOIN employees e ON o.officeCode = e.officeCode
GROUP BY o.officeCode, o.city
HAVING employee_count < 3;

-- Purchase order per office
SELECT 
    o.officeCode,
    o.city,
    COUNT(DISTINCT ord.orderNumber) AS total_orders
FROM offices o
JOIN employees e 
    ON o.officeCode = e.officeCode
JOIN customers c 
    ON e.employeeNumber = c.salesRepEmployeeNumber
JOIN orders ord 
    ON c.customerNumber = ord.customerNumber
GROUP BY o.officeCode, o.city;

-- Stock is stored at the warehouse level
SELECT 
    warehouseCode,
    SUM(quantityInStock) AS total_stock
FROM products
GROUP BY warehouseCode;
