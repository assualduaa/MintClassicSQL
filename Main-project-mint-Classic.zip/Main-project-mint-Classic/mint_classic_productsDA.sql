SELECT * FROM mintclassics.products;
SELECT * FROM mintclassics.productlines;

-- CHECK UNIQUESS OF PK == NO ROWS RETUNED
SELECT *, COUNT(*) AS COUNT FROM products GROUP BY productCode HAVING COUNT(*)>1;
SELECT *, COUNT(*) AS COUNT FROM productlines GROUP BY productLine HAVING COUNT(*)>1;

-- FINDING DUPLICATES ==>N0 DUPLICATES FOUND
WITH CTE AS (
SELECT *, row_number() over(partition by productCode,productLine )AS row_num FROM products)
SELECT * FROM CTE WHERE ROW_NUM>1;

WITH CTE AS (
SELECT *, row_number() over(partition by productLine )AS row_num FROM productlines)
SELECT * FROM CTE WHERE ROW_NUM>1;

-- REMOVE UNEFFECTED COLUMNS
ALTER TABLE productlines
DROP COLUMN htmlDescription;
ALTER TABLE productlines
DROP COLUMN image;

-- CHECKING NULLS ==>NO NULLS
-- Products
SELECT *
FROM products
WHERE productName IS NULL
   OR productLine IS NULL
   OR quantityInStock IS NULL
   OR warehouseCode IS NULL;

-- Productlines
SELECT *
FROM productlines
WHERE textDescription IS NULL;

-- Ensure every product has a valid product line.
SELECT DISTINCT p.productLine
FROM products p
LEFT JOIN productlines pl
    ON p.productLine = pl.productLine
WHERE pl.productLine IS NULL;

-- Standardization Checks
-- Check inconsistent casing
SELECT DISTINCT productLine FROM products; -- > 7 PRODUCTLINES
SELECT DISTINCT warehouseCode FROM products; -- > 4 WAREHOUSES

-- COLUMN CLEAN UP 
UPDATE products
SET
    productCode        = TRIM(UPPER(productCode)),
    productName        = TRIM(LOWER(productName)),
    productLine        = TRIM(LOWER(productLine)),
    productScale       = TRIM(productScale),
    productVendor      = TRIM(productVendor),
    productDescription = TRIM(productDescription),
    warehouseCode      = TRIM(LOWER(warehouseCode));

UPDATE productlines
SET
    textDescription       = TRIM(textDescription);
   
   
-- NUMERIC VALIDATION
-- Negative or illogical values ==> NO ROWS RETURNED
SELECT *
FROM products
WHERE quantityInStock < 0
   OR buyPrice <= 0
   OR MSRP <= 0;

-- -- Loss-making products ==> NO HIGH INVENTORY PRODUCTS
SELECT productCode, buyPrice, MSRP
FROM products
WHERE buyPrice > MSRP;

-- MAIN KPIs YOU MUST FIND
-- Slow-moving stock by product line ==> CLASSIC CAR IS HIGH IN STOCK, TRAIN LOW IN STOCK
SELECT productLine,
       SUM(quantityInStock) AS total_stock
FROM products
GROUP BY productLine
ORDER BY total_stock DESC;

-- Warehouse-wise inventory load ==> d HAS LOW STOCK, SO POTENTIOAL CANDIDATE FOR CLOSURE
SELECT warehouseCode,
       SUM(quantityInStock) AS total_units
FROM products
GROUP BY warehouseCode;

-- High-value products with low stock  ==> These products must remain close to shipping
SELECT productCode, productName, quantityInStock, MSRP
FROM products
WHERE quantityInStock < 50
ORDER BY MSRP DESC;

-- low MARGIN PRODUCTS ==> High-margin products = strategic inventory ==> vintage car is lowest margin products.
SELECT productCode,productLine,
       (MSRP - buyPrice) AS margin
FROM products
ORDER BY margin ;

-- Stock concentration by product line ==> vintage car has low stock
SELECT productLine,
       COUNT(productCode) AS total_products,
       SUM(quantityInStock) AS total_stock
FROM products
GROUP BY productLine;
